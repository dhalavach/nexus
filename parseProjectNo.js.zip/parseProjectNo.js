// importProjectNumbers.js
//
// Reads SPI.xlsx, extracts PROJECT_NO column,
// and updates SpiRecord nodes in Neo4j with project_number property.

const fs = require('fs');
const xlsx = require('xlsx');
const neo4j = require('neo4j-driver');
require('dotenv').config();

const EXCEL_PATH = process.env.SPI_EXCEL || './SPI.xlsx';
const SHEET_NAME = process.env.SPI_SHEET || null;

// Neo4j connection
const NEO4J_URI = process.env.NEO4J_URI || 'neo4j://localhost:7687';
const NEO4J_USER = process.env.NEO4J_USER || 'neo4j';
const NEO4J_PASSWORD = process.env.NEO4J_PASSWORD || 'password';

// --- helper to read Excel ---
function readExcel(filePath, sheetName = null) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Excel file not found: ${filePath}`);
  }
  const wb = xlsx.readFile(filePath, { cellDates: true });
  const actualSheet = sheetName && wb.Sheets[sheetName] ? sheetName : wb.SheetNames[0];
  const sheet = wb.Sheets[actualSheet];
  return xlsx.utils.sheet_to_json(sheet, { defval: null });
}

async function main() {
  console.log(`Reading: ${EXCEL_PATH}`);
  const rows = readExcel(EXCEL_PATH, SHEET_NAME);
  console.log(`Rows: ${rows.length}`);

  const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASSWORD), {
    disableLosslessIntegers: true,
  });

  const session = driver.session();

  try {
    let updated = 0;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];

      // Extract identifying key & project number
      const tagNum = row['TAG_NUMBER'] || row['tag_number'];
      const projectNo = row['PROJECT_NO'] || row['project_no'];

      if (!tagNum) {
        console.warn(`Row ${i + 1}: missing TAG_NUMBER, skipping.`);
        continue;
      }

      // normalize project number
      let pn = projectNo;
      if (typeof pn === 'string') pn = pn.trim();
      if (pn === '') pn = null;

      // Set property only if non-null
      const cypher = `
        MATCH (s:SpiRecord { tag_number: $tag_number })
        SET s.project_number = $pn
        RETURN s.tag_number AS tag
      `;

      const result = await session.writeTransaction((tx) => tx.run(cypher, { tag_number: tagNum.trim(), pn }));

      if (result.records.length > 0) updated++;
    }

    console.log(`Done. Updated ${updated} SpiRecord nodes with project_number.`);
  } catch (err) {
    console.error('Import error:', err);
  } finally {
    await session.close();
    await driver.close();
  }
}

main();
