// npm install xlsx fuzzball
import XLSX from 'xlsx';
import fuzz from 'fuzzball';
import fs from 'fs';

// ====== CONFIG ======
const FILE_PATH = './tags.xlsx'; // path to your Excel file
const TAG_COLUMNS = ['A', 'B', 'C']; // columns to extract tags from
const SIMILARITY_THRESHOLD = 80; // percentage threshold for fuzzy match

// ====== STEP 1: Load Excel file ======
const workbook = XLSX.readFile(FILE_PATH);
const sheetName = workbook.SheetNames[0];
const sheet = workbook.Sheets[sheetName];

// ====== STEP 2: Extract tags ======
const tags = [];

for (const col of TAG_COLUMNS) {
  for (let row = 2; row <= 1000000; row++) {
    // adjust row range
    const cellAddress = `${col}${row}`;
    const cell = sheet[cellAddress];
    if (cell && cell.v) {
      let value = String(cell.v).trim().toUpperCase(); // normalize
      if (value) tags.push(value);
    }
  }
}

// remove duplicates
const uniqueTags = Array.from(new Set(tags));
console.log(`Loaded ${uniqueTags.length} unique tags.`);

// ====== STEP 3: Perform fuzzy matching ======
const matches = [];

for (let i = 0; i < uniqueTags.length; i++) {
  for (let j = i + 1; j < uniqueTags.length; j++) {
    const tag1 = uniqueTags[i];
    const tag2 = uniqueTags[j];

    // compute similarity
    const score = fuzz.ratio(tag1, tag2); // 0-100
    if (score >= SIMILARITY_THRESHOLD) {
      matches.push({ tag1, tag2, score });
    }
  }
}

// ====== STEP 4: Output results ======
console.log(`Found ${matches.length} fuzzy matches with threshold >= ${SIMILARITY_THRESHOLD}:`);
matches.forEach((m) => console.log(`${m.tag1} ↔ ${m.tag2} (${m.score}%)`));

// optional: save to JSON file
fs.writeFileSync('fuzzy_matches.json', JSON.stringify(matches, null, 2));
