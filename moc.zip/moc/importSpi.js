// import_spi.js
// Imports SPI data extract XLSX into Neo4j as SpiRecord nodes.

const fs = require('fs');
const xlsx = require('xlsx');
const neo4j = require('neo4j-driver');
require('dotenv').config();

// Excel location
const EXCEL_PATH = process.env.SPI_EXCEL || './SPI.xlsx';
const SHEET_NAME = process.env.SPI_SHEET_NAME || null;

// Neo4j credentials
// const NEO4J_URI = process.env.NEO4J_URI;
// const NEO4J_USER = process.env.NEO4J_USER;
// const NEO4J_PASSWORD = process.env.NEO4J_PASSWORD;

const NEO4J_URI = 'neo4j://localhost:7687';
const NEO4J_USER = 'neo4j';
const NEO4J_PASSWORD = 'Casablanca';

// HARD-CODED
const SPI_SOR_ID = 'SPI-2025-01';

// Excel → Ontology mapping for SpiSorRecord
const COLUMN_MAP = {
  category: 'CAT',
  component_id: 'CMPNT_ID',
  component_name: 'CMPNT_NAME',
  tag_number: 'TAG_NUMBER',
  discipline: 'DISCIPLINE',
  train: 'Train',
  status: 'STATUS',
  project_status: 'ABS',
};

function readExcel(filePath, sheetName = null) {
  const wb = xlsx.readFile(filePath, { cellDates: true });
  const actualSheet = sheetName && wb.Sheets[sheetName] ? sheetName : wb.SheetNames[0];
  return xlsx.utils.sheet_to_json(wb.Sheets[actualSheet], { defval: null });
}

async function main() {
  console.log(`Reading SPI Excel: ${EXCEL_PATH}`);
  const rows = readExcel(EXCEL_PATH, SHEET_NAME);

  const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASSWORD), {
    disableLosslessIntegers: true,
  });

  const session = driver.session();
  let count = 0;

  try {
    // Ensure SPI SorInstance exists
    await session.executeWrite((tx) =>
      tx.run(
        `
        MERGE (s:SorInstance {sor_id: $id})
        ON CREATE SET s.name = "SPI"
        RETURN s
        `,
        { id: SPI_SOR_ID }
      )
    );

    for (const row of rows) {
      // Build SpiRecord properties
      const props = {};

      for (const [attr, excelCol] of Object.entries(COLUMN_MAP)) {
        let v = row[excelCol];
        if (typeof v === 'string') v = v.trim();
        props[attr] = v ?? null;
      }

      // Build record_id (component ID is stable in SPI)
      if (!props.component_id) {
        console.warn('Skipping row with no CMPNT_ID.');
        continue;
      }

      const record_id = `SPIREC-${props.component_id}`;

      // --------------------------
      // MERGE SpiRecord node
      // --------------------------
      await session.executeWrite((tx) =>
        tx.run(
          `
          MERGE (r:SpiRecord {record_id: $record_id})
          SET r += $props,
              r.composite_name = "SpiRecord_" + $record_id
          RETURN r
        `,
          { record_id, props }
        )
      );

      // --------------------------
      // BELONGS_TO (Record → SOR)
      // --------------------------
      await session.executeWrite((tx) =>
        tx.run(
          `
          MATCH (r:SpiRecord {record_id: $record_id})
          MATCH (s:SorInstance {sor_id: $sor_id})
          MERGE (r)-[:BELONGS_TO]->(s)
          `,
          { record_id, sor_id: SPI_SOR_ID }
        )
      );

      // --------------------------
      // Tag linking (Tag → SpiRecord)
      // --------------------------
      if (props.tag_number) {
        await session.executeWrite((tx) =>
          tx.run(
            `
            MATCH (t:Tag {tag_number: $tag})
            MATCH (r:SpiRecord {record_id: $record_id})
            MERGE (t)-[:PRESENT_IN]->(r)
            `,
            { tag: props.tag_number, record_id }
          )
        );
      }

      count++;
    }

    console.log(`Imported ${count} SPI SpiRecord rows.`);
  } catch (err) {
    console.error('SPI import error:', err);
  } finally {
    await session.close();
    await driver.close();
  }
}

main();
