// import_spi.js
// Import SPI .xlsx file, create SpiRecord nodes, create Tag nodes using tag_number as tag_id,
// and link Tag -> SpiRecord via PRESENT_IN.

const fs = require('fs');
const xlsx = require('xlsx');
const neo4j = require('neo4j-driver');
require('dotenv').config();

// Excel file
const EXCEL_PATH = process.env.SPI_EXCEL || './SPI.xlsx';
const SHEET_NAME = process.env.SPI_SHEET_NAME || null;

// Neo4j connection
// const NEO4J_URI = process.env.NEO4J_URI;
// const NEO4J_USER = process.env.NEO4J_USER;
// const NEO4J_PASSWORD = process.env.NEO4J_PASSWORD;
const NEO4J_URI = 'neo4j://localhost:7687';
const NEO4J_USER = 'neo4j';
const NEO4J_PASSWORD = 'Casablanca';

// SPI SorInstance ID
const SPI_SOR_ID = 'SPI-2025-01';

// Excel → Ontology mapping
const COLUMN_MAP = {
  category: 'CAT',
  component_id: 'CMPNT_ID',
  component_name: 'CMPNT_NAME',
  tag_number: 'TAG_NUMBER',
  discipline: 'DISCIPLINE',
  train: 'Train',
  status: 'STATUS',
  project_status: 'ABS',
};

function readExcel(file, sheet = null) {
  const wb = xlsx.readFile(file, { cellDates: true });
  const actualSheet = sheet && wb.Sheets[sheet] ? sheet : wb.SheetNames[0];
  return xlsx.utils.sheet_to_json(wb.Sheets[actualSheet], { defval: null });
}

async function main() {
  console.log(`Reading SPI extract: ${EXCEL_PATH}`);
  const rows = readExcel(EXCEL_PATH, SHEET_NAME);

  const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASSWORD), {
    disableLosslessIntegers: true,
  });

  const session = driver.session();
  let count = 0;

  try {
    // Ensure SPI SorInstance exists
    await session.executeWrite((tx) =>
      tx.run(
        `
        MERGE (s:SorInstance {sor_id: $id})
        ON CREATE SET s.name = "SPI"
        RETURN s
        `,
        { id: SPI_SOR_ID }
      )
    );

    for (const row of rows) {
      // Extract SpiRecord attributes
      const props = {};
      for (const [attr, col] of Object.entries(COLUMN_MAP)) {
        let v = row[col];
        if (typeof v === 'string') v = v.trim();
        props[attr] = v ?? null;
      }

      if (!props.component_id) {
        console.warn('Skipping row without CMPNT_ID.');
        continue;
      }

      const record_id = `SPIREC-${props.component_id}`;

      // ---------------------------------
      // MERGE SpiRecord node
      // ---------------------------------
      await session.executeWrite((tx) =>
        tx.run(
          `
          MERGE (r:SpiRecord {record_id: $record_id})
          SET r += $props,
              r.composite_name = "SpiRecord_" + $record_id
          `,
          { record_id, props }
        )
      );

      // ---------------------------------
      // BELONGS_TO (Record → SOR Instance)
      // ---------------------------------
      await session.executeWrite((tx) =>
        tx.run(
          `
          MATCH (r:SpiRecord {record_id: $record_id})
          MATCH (s:SorInstance {sor_id: $sor_id})
          MERGE (r)-[:BELONGS_TO]->(s)
          `,
          { record_id, sor_id: SPI_SOR_ID }
        )
      );

      // ---------------------------------
      // Create Tag node and PRESENT_IN
      // ---------------------------------
      if (props.tag_number) {
        const tag_number = props.tag_number.trim();
        const tag_id = tag_number; // EXACTLY as requested

        // Create Tag node (ontology minimal set)
        await session.executeWrite((tx) =>
          tx.run(
            `
            MERGE (t:Tag {tag_id: $tag_id})
            ON CREATE SET 
                t.tag_number = $tag_number,
                t.business_unit = null,
                t.composite_name = "Tag_" + $tag_number
            SET t.tag_number = $tag_number
            `,
            { tag_id, tag_number }
          )
        );

        // Create (t)-[:PRESENT_IN]->(r)
        await session.executeWrite((tx) =>
          tx.run(
            `
            MATCH (t:Tag {tag_id: $tag_id})
            MATCH (r:SpiRecord {record_id: $record_id})
            MERGE (t)-[:PRESENT_IN]->(r)
            `,
            { tag_id, record_id }
          )
        );
      }

      count++;
    }

    console.log(`Imported ${count} SpiRecord rows with Tag node creation.`);
  } catch (err) {
    console.error('SPI import error:', err);
  } finally {
    await session.close();
    await driver.close();
  }
}

main();
