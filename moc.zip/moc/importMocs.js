const fs = require('fs');
const path = require('path');
const xlsx = require('xlsx');
const neo4j = require('neo4j-driver');
const yaml = require('js-yaml');
require('dotenv').config();

const EXCEL_PATH = process.env.EXCEL_PATH || './MoC_example.xlsx';
const SHEET_NAME = process.env.SHEET_NAME || null;
const YAML_SCHEMA_PATH = process.env.YAML_SCHEMA_PATH || './updatedGraphSchema26.11.2025.yaml';

// const NEO4J_URI = process.env.NEO4J_URI;
// const NEO4J_USER = process.env.NEO4J_USER;
// const NEO4J_PASSWORD = process.env.NEO4J_PASSWORD;
const NEO4J_URI = 'neo4j://localhost:7687';
const NEO4J_USER = 'neo4j';
const NEO4J_PASSWORD = 'Casablanca';

if (!NEO4J_URI || !NEO4J_USER || !NEO4J_PASSWORD) {
  console.error('Missing Neo4j credentials. Set NEO4J_URI, NEO4J_USER, NEO4J_PASSWORD in .env');
  process.exit(1);
}

function readExcel(filePath, sheetName = null) {
  if (!fs.existsSync(filePath)) {
    throw new Error(`Excel file not found at ${filePath}`);
  }
  const wb = xlsx.readFile(filePath, { cellDates: true });
  const actualSheet = sheetName && wb.Sheets[sheetName] ? sheetName : wb.SheetNames[0];
  const sheet = wb.Sheets[actualSheet];
  if (!sheet) throw new Error(`Sheet not found: ${sheetName}`);
  const rows = xlsx.utils.sheet_to_json(sheet, { defval: null });
  return rows;
}

function readYamlSchema(yamlPath) {
  if (!fs.existsSync(yamlPath)) {
    console.warn(`YAML schema not found at ${yamlPath}. Proceeding without schema read.`);
    return null;
  }
  const content = fs.readFileSync(yamlPath, 'utf8');
  try {
    return yaml.load(content);
  } catch (err) {
    console.warn('Failed to parse YAML schema:', err.message);
    return null;
  }
}

// Map Excel columns to MOC attributes. If your Excel uses different headers, update this map.
// Expectation: Excel header names should be exact or you can change the keys below.
const COLUMN_MAP = {
  moc_id: 'MOC_ID',
  name: 'MOC_TITLE',
  moc_type: 'MOC_TYPE',
  moc_change_type: 'TYPE_OF_CHANGE',
  moc_status_simple: 'MOC_STATUS_SIMPLE',
  moc_status_actual: 'MOC_STATUS_ACTUAL',
  moc_category: 'MOC_CATEGORY',
  description_of_change: 'DESCRIPTION_OF_CHANGE',
  reason_for_change: 'REASON_FOR_CHANGE',
  work_order_number: 'WORK_ORDER_REF_NUM',
  impact_link: 'IMPACT_Link',
  source: 'Source.Name',
  owner: 'MOC_OWNER',
  //facility: 'facility',
  business_unit: 'SBU_IDENTIFIER',
  location: 'LOCATION',
  specific_location: 'SPECIFIC_LOCATION',
  equipment_type: 'EQUIPMENT_TYPE',

  //associated_with_tag: 'associated_with_tag',
};

async function main() {
  console.log('Reading YAML schema (if provided):', YAML_SCHEMA_PATH);
  const schema = readYamlSchema(YAML_SCHEMA_PATH);
  if (schema) {
    console.log('Schema loaded. Using MOC class attributes from schema (informational).');
    // We won't dynamically derive mapping here, but you can inspect schema.classes.MOC
    // for attribute names if you want to alter COLUMN_MAP automatically.
  }

  console.log('Reading Excel:', EXCEL_PATH);
  const rows = readExcel(EXCEL_PATH, SHEET_NAME);
  console.log(`Found ${rows.length} rows in sheet.`);

  const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASSWORD), {
    disableLosslessIntegers: true,
  });
  const session = driver.session();

  try {
    let imported = 0;
    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      // Build moc properties from COLUMN_MAP; if header missing, value will be undefined/null
      const moc = {};
      for (const [attr, colName] of Object.entries(COLUMN_MAP)) {
        if (row.hasOwnProperty(colName)) {
          let v = row[colName];
          // Normalize empty strings to null
          if (typeof v === 'string') v = v.trim() === '' ? null : v.trim();
          moc[attr] = v === undefined ? null : v;
        } else {
          moc[attr] = null;
        }
      }

      // Validate required field moc_id
      if (!moc.moc_id) {
        console.warn(`Row ${i + 1}: missing required 'moc_id' — skipping row.`);
        continue;
      }

      // Prepare node properties for MERGE (only include non-null fields)
      const props = {};
      for (const [k, v] of Object.entries(moc)) {
        if (v !== null && k !== 'associated_with_tag') {
          props[k] = v;
        }
      }

      // Create/MERGE MOC node by moc_id and set other props with ON CREATE/ON MATCH
      const cypher = `
        MERGE (m:MOC { moc_id: $moc_id })
        ON CREATE SET ${Object.keys(props)
          .map((k, idx) => `m.${k} = $props.${k}`)
          .join(', ')}
        ON MATCH SET ${Object.keys(props)
          .map((k, idx) => `m.${k} = $props.${k}`)
          .join(', ')}
        RETURN m.moc_id as moc_id
      `;
      await session.executeWrite((tx) => tx.run(cypher, { moc_id: moc.moc_id, props }));

      // Handle ASSOCIATED_WITH_TAG relationships if any tag ids provided (comma-separated)
      if (moc.associated_with_tag) {
        // Accept comma or semicolon separation
        const tagIds = String(moc.associated_with_tag)
          .split(/[,;|]/)
          .map((s) => s.trim())
          .filter(Boolean);
        for (const tagId of tagIds) {
          // match Tag node; if it exists, create relationship.
          // If you prefer to create Tag nodes on the fly, change MATCH to MERGE for the Tag node.
          const relCypher = `
            MATCH (m:MOC { moc_id: $moc_id })
            MATCH (t:Tag { tag_id: $tag_id })
            MERGE (m)-[:ASSOCIATED_WITH_TAG]->(t)
            RETURN t.tag_id as tag_id
          `;
          const res = await session.writeTransaction((tx) => tx.run(relCypher, { moc_id: moc.moc_id, tag_id: tagId }));
          if (res.records.length === 0) {
            console.warn(`Warning: Tag ${tagId} not found for MOC ${moc.moc_id}. Relationship not created.`);
          }
        }
      }

      imported++;
    }

    console.log(`Import complete. Created/updated ${imported} MOC nodes (rows processed).`);
  } catch (err) {
    console.error('Error during import:', err);
  } finally {
    await session.close();
    await driver.close();
  }
}

main().catch((err) => {
  console.error('Fatal error:', err);
  process.exit(1);
});
