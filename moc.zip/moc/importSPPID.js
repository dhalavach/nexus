const xlsx = require('xlsx');
const neo4j = require('neo4j-driver');

// ---------------- Neo4j setup ----------------
const NEO4J_URI = 'neo4j://localhost:7687';
const NEO4J_USER = 'neo4j';
const NEO4J_PASSWORD = 'Casablanca';
const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASSWORD));
const session = driver.session();

// ---------------- Excel setup ----------------
const FILE_PATH = './SPPID.xlsx';
const SHEET_NAME = 'Sheet1'; // replace with actual sheet name
const workbook = xlsx.readFile(FILE_PATH);
const worksheet = workbook.Sheets[SHEET_NAME];
const data = xlsx.utils.sheet_to_json(worksheet);

// ---------------- Column normalization ----------------
function normalizeColumns(row) {
  return {
    tagId: row['TAGID'] ? row['TAGID'].toString().trim() : null,
    category: row['CATEGORY'] ? row['CATEGORY'].toString().trim() : null,
    type: row['TYPE'] ? row['TYPE'].toString().trim() : null,
    pidNumber: row['PID NUMBER'] ? row['PID NUMBER'].toString().trim() : null,
    project: row['PROJECT'] ? row['PROJECT'].toString().trim() : null,
  };
}

// ---------------- Main processing ----------------
async function importSppidRecords() {
  try {
    // Create singleton SPPID SorInstance node
    const sorResult = await session.run(`MERGE (s:SorInstance {name: 'SPPID'}) RETURN id(s) AS sorId`);
    const sorId = sorResult.records[0].get('sorId');

    for (const row of data) {
      const normalized = normalizeColumns(row);

      if (!normalized.tagId) continue; // skip rows without tagId

      // MERGE SppidRecord node on guaranteed properties
      const result = await session.run(
        `
                MERGE (r:SppidRecord {pidNumber: $pidNumber, project: $project})
                SET r.category = $category,
                    r.type = $type
                RETURN id(r) AS recordId
                `,
        {
          pidNumber: normalized.pidNumber || '',
          project: normalized.project || '',
          category: normalized.category || null,
          type: normalized.type || null,
        }
      );

      const recordId = result.records[0].get('recordId');

      // Link SppidRecord to SorInstance node
      await session.run(
        `
                MATCH (r:SppidRecord) WHERE id(r) = $recordId
                MATCH (s:SorInstance) WHERE id(s) = $sorId
                MERGE (r)-[:BELONGS_TO]->(s)
                `,
        { recordId, sorId }
      );

      // Create Tag node and link
      await session.run(
        `
                MERGE (t:Tag {tag_number: $tagId})
                WITH t
                MATCH (r:SppidRecord) WHERE id(r) = $recordId
                MERGE (t)-[:PRESENT_IN]->(r)
                `,
        { tagId: normalized.tagId, recordId }
      );
    }

    console.log('SPPID import completed successfully.');
  } catch (err) {
    console.error('Error importing SPPID:', err);
  } finally {
    await session.close();
    await driver.close();
  }
}

// ---------------- Run import ----------------
importSppidRecords();
