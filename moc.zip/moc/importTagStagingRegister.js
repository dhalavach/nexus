const xlsx = require('xlsx');
const neo4j = require('neo4j-driver');

// ---------------- Neo4j setup ----------------
const NEO4J_URI = 'neo4j://localhost:7687';
const NEO4J_USER = 'neo4j';
const NEO4J_PASSWORD = 'Casablanca';
const driver = neo4j.driver(NEO4J_URI, neo4j.auth.basic(NEO4J_USER, NEO4J_PASSWORD));
const session = driver.session();

// ---------------- Excel setup ----------------
const FILE_PATH = './TagStagingRegister.xlsx';
const SHEET_NAME = 'Sheet1'; // replace with actual sheet name
const workbook = xlsx.readFile(FILE_PATH);
const worksheet = workbook.Sheets[SHEET_NAME];
const data = xlsx.utils.sheet_to_json(worksheet);

// ---------------- Helper: create regex patterns ----------------
function createMocRegex(mocId) {
  const escaped = mocId.toString().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // escape special chars
  // Matches: exact number, MOC_<number>, MOC<number>, optionally with a prefix ending with '/'
  return new RegExp(`(^|/)` + `(MOC_?${escaped}|${escaped})$`);
}

// ---------------- Main processing ----------------
async function associateTags() {
  try {
    // Fetch all MOC nodes with their IDs
    const mocResult = await session.run(`MATCH (m:MOC) RETURN m.moc_id AS moc_id, id(m) AS nodeId`);
    const mocs = mocResult.records.map((r) => ({ moc_id: r.get('moc_id'), nodeId: r.get('nodeId') }));

    for (const moc of mocs) {
      const regex = createMocRegex(moc.moc_id);

      // Find matching tags in Excel
      const matchingTags = data
        .filter((row) => row['Project or MOC number'] && regex.test(row['Project or MOC number'].toString()))
        .map((row) => row['TagNumber'].toString().trim())
        .filter(Boolean);

      for (const tagNumber of matchingTags) {
        // Create Tag node if not exists and connect
        await session.run(
          `
                    MERGE (t:Tag {tag_number: $tagNumber})
                    WITH t
                    MATCH (m:MOC) WHERE id(m) = $mocNodeId
                    MERGE (m)-[:ASSOCIATED_WITH]->(t)
                    `,
          { tagNumber, mocNodeId: moc.nodeId }
        );
      }
    }

    console.log('Tag association completed.');
  } catch (err) {
    console.error('Error:', err);
  } finally {
    await session.close();
    await driver.close();
  }
}

associateTags();
